package com.cg.ibs.im.controller;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.ibs.im.exception.IBSCustomException;
import com.cg.ibs.im.exception.IBSException;
import com.cg.ibs.im.model.AccountType;
import com.cg.ibs.im.model.Application;
import com.cg.ibs.im.model.ApplicationStatus;
import com.cg.ibs.im.model.Banker;
import com.cg.ibs.im.model.Customer;
import com.cg.ibs.im.model.Message;
import com.cg.ibs.im.service.BankerService;
import com.cg.ibs.im.service.CustomerService;

@Controller
@RequestMapping("/bank")
@CrossOrigin
public class BankController {

	@Autowired
	private BankerService bankerService;

	@Autowired
	private CustomerService customerService;

	@PostMapping
	public ResponseEntity<Message> bankerLogin(@RequestBody Banker bankAdmin) throws IBSCustomException {
		ResponseEntity<Message> responseEntity;
		Message message = new Message();
		Banker banker = new Banker();
		
			if (bankAdmin.getUserId() == null || bankAdmin.getUserId().equals("")) {
				message.setMessage("No user details found");
				responseEntity = new ResponseEntity<Message>(message, HttpStatus.BAD_REQUEST);
			} else if (bankerService.verifyBankerLogin(bankAdmin.getUserId(), bankAdmin.getPassword())) {
				message.setMessage("Welcome");
				banker = bankerService.getBanker(bankAdmin.getUserId());
				message.setBanker(banker);
				responseEntity = new ResponseEntity<Message>(message, HttpStatus.OK);
			} else {
				throw new IBSCustomException(IBSException.invalidBankerId);
//				responseEntity = new ResponseEntity<Message>(message, HttpStatus.UNAUTHORIZED);
			}
		
		return responseEntity;
	}

	@GetMapping
	public ResponseEntity<Message> getAllApplications() {
		ResponseEntity<Message> responseEntity;
		Message message = new Message();
		try {
			Set<Application> applications = bankerService.getAllApplications();
			message.setMessage("Applications retrieved");
			message.setApplications(applications);
			responseEntity = new ResponseEntity<Message>(message, HttpStatus.OK);
		} catch (Exception exception) {
			message.setMessage("Internal Error");
			responseEntity = new ResponseEntity<Message>(message, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@GetMapping("/pending")
	public ResponseEntity<Message> getAllPendingApplications() {
		ResponseEntity<Message> responseEntity;
		Message message = new Message();
		try {
			Set<Application> applications = bankerService.viewPendingApplications();
			message.setMessage("Applications retrieved");
			message.setApplications(applications);
			responseEntity = new ResponseEntity<Message>(message, HttpStatus.OK);
		} catch (Exception exception) {
			message.setMessage("Internal Error");
			responseEntity = new ResponseEntity<Message>(message, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@GetMapping("/approved")
	public ResponseEntity<Message> getAllApprovedApplications() {
		ResponseEntity<Message> responseEntity;
		Message message = new Message();
		try {
			Set<Application> applications = bankerService.viewApprovedApplications();
			message.setMessage("Applications retrieved");
			message.setApplications(applications);
			responseEntity = new ResponseEntity<Message>(message, HttpStatus.OK);
		} catch (Exception exception) {
			message.setMessage("Internal Error");
			responseEntity = new ResponseEntity<Message>(message, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@GetMapping("/denied")
	public ResponseEntity<Message> getAllDeniedApplications() {
		ResponseEntity<Message> responseEntity;
		Message message = new Message();
		try {
			Set<Application> applications = bankerService.viewDeniedApplications();
			message.setMessage("Applications retrieved");
			message.setApplications(applications);
			responseEntity = new ResponseEntity<Message>(message, HttpStatus.OK);
		} catch (Exception exception) {
			message.setMessage("Internal Error");
			responseEntity = new ResponseEntity<Message>(message, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@GetMapping("/applicationDetails/{applicationId}")
	public ResponseEntity<Message> viewApplicantDetails(@PathVariable("applicationId") Long applicationId) {
		ResponseEntity<Message> responseEntity;
		System.out.println(applicationId);
		Message message = new Message();
		try {

			if (bankerService.isApplicationPresent(applicationId)) {

				Application application = bankerService.displayDetails(applicationId);
				application.getPrimaryApplicant().setAadharDocument(null);
				application.getPrimaryApplicant().setPanDocument(null);
				
				
				// JOINT

				if(null!=application.getSecondaryApplicant()) {
					application.getSecondaryApplicant().setAadharDocument(null);
					application.getSecondaryApplicant().setPanDocument(null);
				}
				message.setApplication(application);
				message.setMessage(application.getApplicationId().toString());
				responseEntity = new ResponseEntity<Message>(message, HttpStatus.OK);
			} else {
				message.setMessage("INVALID APPLICANT ID");
				responseEntity = new ResponseEntity<Message>(message, HttpStatus.BAD_REQUEST);
			}

		} catch (Exception exception) {
			exception.printStackTrace();
			message.setMessage("Internal Error");
			responseEntity = new ResponseEntity<Message>(message, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@GetMapping("/pendingBanker/{bankerId}")
	public ResponseEntity<Message> getAllPendingForBankerApplications(@PathVariable Integer bankerId) {
		ResponseEntity<Message> responseEntity;
		Message message = new Message();
		try {
			Set<Application> applications = bankerService.viewPendingApplicationsBanker(bankerId);
			message.setMessage("Applications retrieved");
			message.setApplications(applications);
			responseEntity = new ResponseEntity<Message>(message, HttpStatus.OK);
		} catch(Exception exception) {
			message.setMessage("Internal Error");
			responseEntity = new ResponseEntity<Message>(message, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@PostMapping("/approve/{applicationId}")
	public ResponseEntity<Message> approveApplicant(@PathVariable("applicationId") Long applicationId, @RequestBody Application application) {
		ResponseEntity<Message> responseEntity;
		Message message = new Message();
		try {
			Application applicationNew = bankerService.displayDetails(applicationId);
			Customer customer = new Customer();
			if(application.getApplicationStatus()==ApplicationStatus.PENDING) {
				if(application.getAccountType()==AccountType.SAVINGS) {
					customer = bankerService.createNewCustomer(applicationNew);
				} else {
					customer = bankerService.createNewCustomer(applicationNew);
				}
				applicationNew.setApplicationStatus(ApplicationStatus.APPROVED);
				customerService.updateApplication(applicationNew);
				message.setMessage("Application approved");
				message.setCustomer(customer);
				message.setApplication(applicationNew);
				responseEntity = new ResponseEntity<Message>(message, HttpStatus.OK);
			} else {
				message.setMessage("Application can't be approved");
				responseEntity = new ResponseEntity<Message>(message, HttpStatus.BAD_REQUEST);
			}
			
//			if(applicantBean.getApplicantStatus()==ApplicantStatus.PENDING) {
//				applicantBean.setApplicantStatus(ApplicantStatus.APPROVED);
//				if(applicantBean.getAccountType()==AccountType.SAVINGS) {
//					Customer customer = bankerService.createNewCustomer(applicantBean);
//					Set<AccountHolding> ahb = customer.getAccountHoldings();
//					AccountHolding customerHoldings = new AccountHolding();
//					for(AccountHolding ah : ahb) {
//						customerHoldings = ah;
//					}
//					String result = "APPROVED-----UCI: "+ customer.getUci().toString()+"-------User Id: "+customer.getUserId() +"---------Account Number: "+ customerHoldings.getAccount().getAccNo().toString();
//					responseEntity = new ResponseEntity<String>(result, HttpStatus.OK);
//				} else {
//					Customer customer = bankerService.createNewCustomer(applicantBean);
//					Set<AccountHolding> ahb = customer.getAccountHoldings();
//					AccountHolding customerHoldings = new AccountHolding();
//					for(AccountHolding ah : ahb) {
//						customerHoldings = ah;
//					}
//					Applicant linkedApplicant = customerService.getApplicantDetails(applicantBean.getLinkedApplication());
//					Customer secCustomer = bankerService.createNewCustomer(linkedApplicant);
//					String result = "APPROVED-----UCI: "+ customer.getUci().toString()+"-------User Id: "+customer.getUserId()+"----SECONDARY CUSTOMER: UCI:" + secCustomer.getUci().toString()+"-------user id: " + secCustomer.getUserId() +"---------Account Number: "+ customerHoldings.getAccount().getAccNo().toString()+ "********here***************";
//					responseEntity = new ResponseEntity<String>(result, HttpStatus.OK);
//				}
//			} else {
//				responseEntity = new ResponseEntity<String>("Application doesn't exist in pending list, you can't approve it.", HttpStatus.BAD_REQUEST);
//			}
		} catch (Exception exception) {
			exception.printStackTrace();
			message.setMessage("Internal Error");
			responseEntity = new ResponseEntity<Message>(message, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		return responseEntity;
	}
	
	@PostMapping("/deny/{applicationId}")
	public ResponseEntity<Message> denyApplicant(@PathVariable("applicationId") Long applicationId, @RequestBody Application application) {
		ResponseEntity<Message> responseEntity;
		Message message = new Message();
		try {
			
			Application applicationNew = bankerService.displayDetails(applicationId);
			if(applicationNew.getApplicationStatus()==ApplicationStatus.PENDING) {
				
				System.out.println(application.getRemarks());
				applicationNew.setRemarks(application.getRemarks());
				applicationNew.setApplicationStatus(ApplicationStatus.DENIED);
				customerService.updateApplication(applicationNew);
				message.setMessage("application denied");
				message.setApplication(applicationNew);
				responseEntity = new ResponseEntity<Message>(message, HttpStatus.OK);
			} else {
				message.setMessage("can't be denied");
				responseEntity = new ResponseEntity<Message>(message, HttpStatus.BAD_REQUEST);
			}	
		} catch (Exception exception) {
			exception.printStackTrace();
			message.setMessage("Internal Error");
			responseEntity = new ResponseEntity<Message>(message, HttpStatus.INTERNAL_SERVER_ERROR);
		}
 		return responseEntity;
	}
	
	@ExceptionHandler(IBSCustomException.class)
	public ResponseEntity<String> handleIBSException(IBSCustomException exp) {
		exp.printStackTrace();
		return new ResponseEntity<String>(exp.getMessage(), HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<String> handleException(Exception exp) {
		return new ResponseEntity<String>(exp.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
