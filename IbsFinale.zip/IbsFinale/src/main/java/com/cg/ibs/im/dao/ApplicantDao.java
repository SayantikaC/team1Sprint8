package com.cg.ibs.im.dao;

import java.util.Set;

import com.cg.ibs.im.model.Applicant;
import com.cg.ibs.im.model.ApplicationStatus;
import com.cg.ibs.im.exception.IBSCustomException;

public interface ApplicantDao {
	
	Long saveApplicant(Applicant applicant) throws IBSCustomException;
	
	Set<Long> getAllApplicants() throws IBSCustomException;
	
	Set<Applicant> getApplicantsByStatus(ApplicationStatus applicantStatus) throws IBSCustomException;

	boolean isApplicantPresent(long applicantId) throws IBSCustomException;

	boolean updateApplicant(Applicant applicant) throws IBSCustomException;

	Applicant getApplicantDetails(Long applicantId) throws IBSCustomException;
	
}
