package com.cg.ibs.im.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="accountholdings")
public class AccountHolding implements Serializable{
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="ahid")
    private Long aHId;
    
    @JsonIgnore
    @ManyToOne
    private Customer customer;
	@ManyToOne
    private Account account;
    @Enumerated(EnumType.STRING)
    @Column(name="type")
    private AccountHoldingType type;
    
    public AccountHolding() {
        super();
    }
    

    public Long getaHId() {
        return aHId;
    }

    public void setaHId(Long aHId) {
        this.aHId = aHId;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Account getAccount() {
        return account;
    }

    public void setAccount(Account account) {
        this.account = account;
    }

    public AccountHoldingType getType() {
        return type;
    }

    public void setType(AccountHoldingType type) {
        this.type = type;
    }
}