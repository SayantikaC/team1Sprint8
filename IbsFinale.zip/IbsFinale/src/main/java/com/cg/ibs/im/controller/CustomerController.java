package com.cg.ibs.im.controller;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ibs.im.exception.IBSCustomException;
import com.cg.ibs.im.exception.IBSException;
import com.cg.ibs.im.model.AccountType;
import com.cg.ibs.im.model.Applicant;
import com.cg.ibs.im.model.Application;
import com.cg.ibs.im.model.Customer;
import com.cg.ibs.im.model.Message;
import com.cg.ibs.im.model.Password;
import com.cg.ibs.im.service.BankerService;
import com.cg.ibs.im.service.CustomerService;

@RestController
@RequestMapping("/customer")
@Scope("session")
@CrossOrigin
public class CustomerController {

	@Autowired
	private CustomerService customerService;
	@Autowired
	private BankerService bankerService;

	private Customer cust;

	@PostMapping
	public ResponseEntity<Message> customerLogin(@RequestBody Customer customer) throws IBSCustomException {
		ResponseEntity<Message> result = new ResponseEntity<Message>(HttpStatus.BAD_REQUEST);
		Message message = new Message();
		System.out.println("sdhwe");

		if (customer.getUserId() == null || customer.getUserId().equals("")) {
			message.setMessage("No user details found");
			result = new ResponseEntity<>(message, HttpStatus.BAD_REQUEST);
		} else {

			if (customerService.login(customer.getUserId(), customer.getPassword())) {
				cust = customerService.getCustomerDetails(customer.getUserId());
				System.out.println("reached");
				message.setMessage("Welcome " + cust.getFirstName() + " " + cust.getLastname());
				message.setCustomer(cust);
				result = new ResponseEntity<>(message, HttpStatus.OK);
			} else {
				// throw new IBSCustomException(IBSException.incorrectUsernamePassword);
				System.out.println("Here after");
			}
		}
		return result;
	}

	@GetMapping
	public ResponseEntity<Set<Customer>> getAllCustomers() {
		try {
			return new ResponseEntity<Set<Customer>>(customerService.getAllCustomers(), HttpStatus.OK);
		} catch (Exception exception) {
			Set<Customer> set = new HashSet<Customer>();
			return new ResponseEntity<Set<Customer>>(set, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PostMapping(value = "/checkStatus/{applicationId}")
	public ResponseEntity<Message> applicationStatus(@PathVariable("applicationId") Long applicationId) throws IBSCustomException {

		ResponseEntity<Message> result;
		Message message = new Message();
		
		if(bankerService.isApplicationPresent(applicationId)) {
			Application application = bankerService.displayDetails(applicationId);
			String accountType = application.getAccountType().toString();
			message.setMessage(customerService.checkStatus(applicationId).toString());
			message.setApplication(application);
			if (message == null) {
				result = new ResponseEntity<Message>(message, HttpStatus.BAD_REQUEST);
			} else if (message.getMessage().equals("APPROVED")) {
				Customer customer = customerService.getCustomerByApplicantId(applicationId);
				message.setCustomer(customer);
				if (application.getAccountType() == AccountType.SAVINGS) {

					result = new ResponseEntity<Message>(message, HttpStatus.OK);
				} else {

					result = new ResponseEntity<Message>(message, HttpStatus.OK);
				}
			} else if (message.equals("DENIED")) {
				result = new ResponseEntity<Message>(message, HttpStatus.OK);
			} else {
				result = new ResponseEntity<Message>(message, HttpStatus.OK);
			}
		} else {
			throw new IBSCustomException(IBSException.invalidApplicantId);
		}
			
		
		return result;
	}

	@PostMapping(value = "/updatePassword")
	public ResponseEntity<Message> updateCustomerPassword(@RequestBody Password password) {
		ResponseEntity<Message> result;
		Message message = new Message();
		String password1 = password.getNewPassword();
		String password2 = password.getConfirmPassword();

		try {
			System.out.println(password.getUserId());
			cust = customerService.getCustomerByUserId(password.getUserId());
			if (password1.equals("") || password2.equals("")) {
				message.setMessage("REQUIRED FIELDS can't be left empty");
				result = new ResponseEntity<Message>(message, HttpStatus.UNAUTHORIZED);
			} else if (!customerService.checkCustomerDetails(password1, password2)) {
				message.setMessage("Passwords don't match. Update failed");
				result = new ResponseEntity<Message>(message, HttpStatus.UNAUTHORIZED);
			} else {
				if (cust.getLogin() == 0) {
					cust.setPassword(password1);
					if (customerService.updateCustomer(cust)) {
						message.setCustomer(cust);
						message.setMessage("Welcome");
						result = new ResponseEntity<Message>(message, HttpStatus.OK);
					} else {
						message.setMessage("password updation failed");
						result = new ResponseEntity<Message>(message, HttpStatus.BAD_REQUEST);
					}
				} else {
					message.setMessage("Password Updation failed, not your first Login");
					result = new ResponseEntity<Message>(message, HttpStatus.BAD_REQUEST);
				}
			}
		} catch (IBSCustomException exception) {
			message.setMessage("Password Updation failed");
			result = new ResponseEntity<Message>(message, HttpStatus.UNAUTHORIZED);
			exception.printStackTrace();
		}
		return result;
	}

	@ExceptionHandler(IBSCustomException.class)
	public ResponseEntity<String> handleIBSException(IBSCustomException exp) {
		exp.printStackTrace();
		return new ResponseEntity<String>(exp.getMessage(), HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<String> handleException(Exception exp) {
		return new ResponseEntity<String>(exp.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	}
}