package com.cg.ibs.im.dao;

import com.cg.ibs.im.exception.IBSCustomException;
import com.cg.ibs.im.model.Banker;

public interface BankerDao {

//	BankAdmins addNewBanker();
	
	boolean checkBankerLogin(String adminId, String password) throws IBSCustomException;

	Banker getBanker(String userId) throws IBSCustomException;

}
