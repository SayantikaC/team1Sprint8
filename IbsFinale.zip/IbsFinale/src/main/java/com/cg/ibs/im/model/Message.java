package com.cg.ibs.im.model;

import java.util.Set;

public class Message {
	
	private String message;
	private Customer customer;
	private Banker banker;
	private Customer secondary;
	private Application application;
	private Set<Application> applications;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Application getApplication() {
		return application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

	public Customer getSecondary() {
		return secondary;
	}

	public void setSecondary(Customer secondary) {
		this.secondary = secondary;
	}

	public Banker getBanker() {
		return banker;
	}

	public void setBanker(Banker banker) {
		this.banker = banker;
	}

	public Set<Application> getApplications() {
		return applications;
	}

	public void setApplications(Set<Application> applications) {
		this.applications = applications;
	}
	
	
}
