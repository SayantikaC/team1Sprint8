package com.cg.ibs.im.controller;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ibs.im.model.AccountType;
import com.cg.ibs.im.model.Application;
import com.cg.ibs.im.model.ApplicationStatus;
import com.cg.ibs.im.model.Message;
import com.cg.ibs.im.service.BankerService;
import com.cg.ibs.im.service.CustomerService;

@RestController
@RequestMapping("/application")
@CrossOrigin
public class ApplicationController {

	@Autowired
	private CustomerService customerService;
	
	@Autowired
	private BankerService bankerService;

	@GetMapping
	public ResponseEntity<Set<Application>> getAllApplications() {
		try {
			return new ResponseEntity<Set<Application>>(customerService.getAllApplications(), HttpStatus.OK);
		} catch (Exception exception) {
			Set<Application> set = new HashSet<Application>();
			return new ResponseEntity<Set<Application>>(set, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PostMapping
	public ResponseEntity<Message> signUp(@RequestBody Application application) {
		ResponseEntity<Message> responseEntity;
		Message message = new Message();
		try {
			application.setAccountType(AccountType.SAVINGS);
			Long applicationId = customerService.saveApplicationDetails(application);
			message.setMessage(applicationId.toString());
			Application applicationNew = bankerService.displayDetails(applicationId);
			message.setApplication(applicationNew);
			responseEntity = new ResponseEntity<Message>(message, HttpStatus.OK);

		} catch (Exception exception) {
			exception.printStackTrace();
			message.setMessage("Internal Error");
			responseEntity = new ResponseEntity<Message>(message, HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return responseEntity;
	}
}
