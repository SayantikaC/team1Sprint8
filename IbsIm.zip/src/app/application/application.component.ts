import { Component, OnInit } from '@angular/core';
import { Application } from '../model/application.model';
import { Router, ActivatedRoute } from '@angular/router';
import { Routes, RouterModule } from '@angular/router';
import { Applicant } from '../model/applicant.model';

@Component({
  selector: 'app-application',
  templateUrl: './application.component.html',
  styleUrls: ['./application.component.css']
})
export class ApplicationComponent implements OnInit {

  application:Application;
  applicant: Applicant;
  isJoint: boolean;

  constructor(private router: Router, private actRt: ActivatedRoute){
    this.applicant = new Applicant();
    this.isJoint= false;
  }

  ngOnInit() {
    this.load();
  }

  load() {
    this.application = JSON.parse(localStorage.getItem('appl'));
    if(this.application.accountType == "JOINT_SAVINGS") {
      this.isJoint = true;
      console.log(this.isJoint);
    }
    this.applicant = this.application.primaryApplicant;
  }

  logout() {
    sessionStorage.remove('logged');
    this.router.navigateByUrl("");
  }

}
