import { Customer } from './customer.model';
import { Account } from './account.model';

export class AccountHolding {

    aHId: number;
    customer: Customer;
    account: Account;
    type: AccountHoldingType;
}

enum AccountHoldingType{
    PRIMARY, SECONDARY, INDIVIDUAL
}
