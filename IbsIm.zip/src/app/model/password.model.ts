export class Password {

    public newPassword: string;
    public confirmPassword: string;
    public userId: string;
}
