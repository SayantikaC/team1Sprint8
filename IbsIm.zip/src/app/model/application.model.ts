import { Applicant } from './applicant.model';

export class Application {
    applicationId: number;
    applicationStatus: string;
    applicationDate: Date;
    remarks: string;
    assignedBanker: number;
    accountType: string;
    primaryApplicant: Applicant;
    secondaryApplicant: Applicant;
}