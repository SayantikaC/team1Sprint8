export class Address {

    addressId: number;
    permanentHouseNumber: String;
    permanentStreetName: String;
    permanentArea: String;
    permanentLandmark: String;
    permanentCity: String;
    permanentState: String;
    permanentCountry: String;
    permanentPincode: String;
    currentHouseNumber: String;
    currentStreetName: String;
    currentArea: String;
    currentLandmark: String;
    currentCity: String;
    currentState: String;
    currentCountry: String;
    currentPincode: String;

}
