import { AccountHolding } from './account-holding.model';

describe('AccountHolding', () => {
  it('should create an instance', () => {
    expect(new AccountHolding()).toBeTruthy();
  });
});
