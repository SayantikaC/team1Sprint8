import { Application } from './application.model';

describe('Application', () => {
  it('should create an instance', () => {
    expect(new Application()).toBeTruthy();
  });
});
