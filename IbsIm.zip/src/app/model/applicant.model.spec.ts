import { Applicant } from './applicant.model';

describe('Applicant', () => {
  it('should create an instance', () => {
    expect(new Applicant()).toBeTruthy();
  });
});
