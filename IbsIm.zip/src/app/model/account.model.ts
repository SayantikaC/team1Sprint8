import { AccountHolding } from './account-holding.model';

export class Account {
    accNo: number;
    balance: number;
    trans_Pwd: String;
    accCreationDate: Date;
    openBalance: number;
    accStatus: AccountStatus;
    accType: AccountType;
    tenure: number;
    maturityAmt: number;
    accountHoldings: AccountHolding[];
}

enum AccountStatus{
    ACTIVE, CLOSED
}

enum AccountType{
    SAVINGS, FIXED_DEPOSIT, RECURRING_DEPOSIT, JOINT_SAVINGS
}