import { Customer } from './customer.model';
import { Banker } from './banker.model';
import { Application } from './application.model';


export class Message {
    public message:string;
    public customer:Customer;
    public banker: Banker;
    public secondary: Customer;
    public application: Application;
    public applications: Application[];
}
