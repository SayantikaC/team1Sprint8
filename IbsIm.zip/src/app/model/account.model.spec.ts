import { Account } from './account.model';

describe('Account', () => {
  it('should create an instance', () => {
    expect(new Account()).toBeTruthy();
  });
});
