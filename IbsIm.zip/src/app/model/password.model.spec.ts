import { Password } from './password.model';

describe('Password', () => {
  it('should create an instance', () => {
    expect(new Password()).toBeTruthy();
  });
});
