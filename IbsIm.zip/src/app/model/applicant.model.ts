import { Address } from './address.model';

export class Applicant {
    applicantId: number;
    firstName: String;
    lastName: String;
    fatherName: String;
    motherName: String;
    dob: Date;
    gender: string;
    mobileNumber: String;
    alternateMobileNumber: String;
    emailId: String;
    aadharNumber: String;
    panNumber: String;
    address: Address;
    aadharDocument: File;
    panDocument: File;
}
