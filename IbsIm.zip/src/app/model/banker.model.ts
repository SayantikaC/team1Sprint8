export class Banker {

    public bankerId:number;
    public userId:String;
    public password:String;
}
