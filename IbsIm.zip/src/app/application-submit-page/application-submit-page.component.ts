import { Component, OnInit } from '@angular/core';
import { Application } from '../model/application.model';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-application-submit-page',
  templateUrl: './application-submit-page.component.html',
  styleUrls: ['./application-submit-page.component.css']
})
export class ApplicationSubmitPageComponent implements OnInit {

  application:Application;

  constructor(private router: Router, private actRt: ActivatedRoute) { 
    this.application= new Application();
  }

  ngOnInit() {
    this.load();
  }
load(){
  this.application = JSON.parse(localStorage.getItem('newAppl'));
  console.log(this.application.applicationId);
} 

logout() {
  sessionStorage.remove('logged');
  this.router.navigateByUrl("");
}
}
