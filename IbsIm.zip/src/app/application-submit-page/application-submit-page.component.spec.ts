import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApplicationSubmitPageComponent } from './application-submit-page.component';

describe('ApplicationSubmitPageComponent', () => {
  let component: ApplicationSubmitPageComponent;
  let fixture: ComponentFixture<ApplicationSubmitPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApplicationSubmitPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApplicationSubmitPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
