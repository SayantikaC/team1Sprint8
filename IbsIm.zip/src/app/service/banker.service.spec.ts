import { Banker } from './banker.service';

describe('Banker', () => {
  it('should create an instance', () => {
    expect(new Banker()).toBeTruthy();
  });
});
