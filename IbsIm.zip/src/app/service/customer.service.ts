import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable, throwError } from 'rxjs';
import { Customer } from '../model/customer.model';
import { Message } from '../model/message.model';
import { Password } from '../model/password.model';
import { Applicant } from '../model/applicant.model';
import { Application } from '../model/application.model';
import { catchError } from 'rxjs/operators';


@Injectable({
    providedIn: 'root'
  })
export class CustomerService {

    errorMessage: string;
    loggedIn: boolean;

    baseUrl:string;
    baseUrlAppl: string;
    appId: number;
    password:Password;

    constructor(private http:HttpClient) {
        this.baseUrl=`${environment.baseMwUrlCustomer}`;
        this.loggedIn= false;
        this.baseUrlAppl = `${environment.baseMwUrlApplication}`;
        this.password = new Password();
        this.errorMessage = "something went wrong";
    }

    getAll(): Observable<Customer[]> {
        return this.http.get<Customer[]>(this.baseUrl);
      }

    login(customer:Customer): Observable<Message> {
        return this.http.post<Message>(this.baseUrl, customer).pipe(catchError(this.errorHandler));        
    }

    checkStatus(applicationId: number): Observable<Message> {
        this.appId = applicationId;
        // console.log(this.appId);
        // console.log(applicationId);
        return this.http.post<Message>(`${this.baseUrl}/checkStatus/${this.appId}`, applicationId).pipe(catchError(this.errorHandler))
    }

    updatePassword(pass: Password): Observable<Message> {
        this.password.newPassword = pass.newPassword;
        this.password.confirmPassword = pass.confirmPassword;
        this.password.userId = pass.userId;
        return this.http.post<Message>(`${this.baseUrl}/updatePassword`, this.password);        
    }

    signup(application: Application): Observable <Message>{
        return this.http.post<Message>(this.baseUrlAppl, application); 
    }

    errorHandler(error: HttpErrorResponse) {
        if (error.error instanceof ErrorEvent) {
            // A client-side or network error occurred. Handle it accordingly.
            console.error('An error occurred:', error.error.message);
          } else {
            // The backend returned an unsuccessful response code.
            // The response body may contain clues as to what went wrong,
            this.errorMessage = error.error;
            console.error(
              `Backend returned code ${error.status}, ` +
              `body was: ${error.error}`);
          }
          // return an observable with a user-facing error message
          return throwError(
            this.errorMessage);
    }

}
