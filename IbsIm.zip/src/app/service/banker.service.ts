import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable, throwError } from 'rxjs';
import { Message } from '../model/message.model';
import { Banker } from '../model/banker.model';
import { Application } from '../model/application.model';
import { catchError } from 'rxjs/operators';


@Injectable({
    providedIn: 'root'
  })
export class BankerService {
    baseUrl:string;
    errorMessage: string;
    loggedIn: boolean;

    // baseUrlApp: string;
    banker:Banker;
    application: Application;
    applicationId: number;
    bankers: Banker[];
    bankerId: number;

    constructor(private http:HttpClient) {
        this.baseUrl=`${environment.baseMwUrlBank}`;
        this.loggedIn= false;
        // this.baseUrlApp = `${environment.baseMwUrlApplication}`
        this.banker = new Banker();
        this.application = new Application();
        this.applicationId = 0;
        this.bankerId = -1;
        this.errorMessage = "something went wrong";
    }
      
    login(banker:Banker): Observable<Message> {
        return this.http.post<Message>(this.baseUrl,banker).pipe(catchError(this.errorHandler)); 
    }
     
    getAllApplications(): Observable<Message> {
        return this.http.get<Message>(this.baseUrl);
    }

    getAllApprovedApplications(): Observable<Message> {
        return this.http.get<Message>(`${this.baseUrl}/approved`);
    }
    
    getAllPendingApplications(): Observable<Message> {
        return this.http.get<Message>(`${this.baseUrl}/pending`);
    }
    
    getAllDeniedApplications(): Observable<Message> {
        return this.http.get<Message>(`${this.baseUrl}/denied`);
    }

    viewApplication(appId: number) : Observable<Message> {
        console.log(appId);
        this.applicationId = appId;
        console.log(this.applicationId);
        return this.http.get<Message>(`${this.baseUrl}/applicationDetails/${this.applicationId}`)
    }

    getAllPendingForBankerApplications(bankId: number): Observable<Message> {
        this.bankerId = bankId;
        console.log(this.bankerId);
        return this.http.get<Message>(`${this.baseUrl}/pendingBanker/${this.bankerId}`);
    }

    denyApplication(application: Application): Observable<Message> {
        this.applicationId = application.applicationId;
        console.log(this.applicationId);
        return this.http.post<Message>(`${this.baseUrl}/deny/${this.applicationId}`, application);
    }

    approveApplication(application: Application): Observable<Message> {
        return this.http.post<Message>(`${this.baseUrl}/approve/${this.applicationId}`, application);
    }
    errorHandler(error: HttpErrorResponse) {
        if (error.error instanceof ErrorEvent) {
            // A client-side or network error occurred. Handle it accordingly.
            console.error('An error occurred:', error.error.message);
          } else {
            // The backend returned an unsuccessful response code.
            // The response body may contain clues as to what went wrong,
            this.errorMessage = error.error;
            console.error(
              `Backend returned code ${error.status}, ` +
              `body was: ${error.error}`);
          }
          // return an observable with a user-facing error message
          return throwError(
            this.errorMessage);
    }

}
