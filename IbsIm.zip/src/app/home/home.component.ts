import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../service/customer.service';
import { Message } from '../model/message.model';
import { ActivatedRoute, Router } from '@angular/router';
import { Customer } from '../model/customer.model';
import { AccountHolding } from '../model/account-holding.model';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
message:Message;
customer:Customer;
accountHoldings: AccountHolding[];

  constructor(private customerService:CustomerService, private actRt: ActivatedRoute, private router: Router) {
      this.accountHoldings = [];
   }

  ngOnInit() {
    this.load();
  }

  load() {
    
      this.customer = JSON.parse(localStorage.getItem('c'));
      this.accountHoldings = this.customer.accountHoldings;
  }

  logout() {
    sessionStorage.remove('logged');
    this.router.navigateByUrl("");
  }

}
