import { Component } from '@angular/core';
import { Route, Router, ActivatedRoute } from '@angular/router';
import { Banker } from './model/banker.model';
import { Customer } from './model/customer.model';
import { BankerService } from './service/banker.service';
import { CustomerService } from './service/customer.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'IbsIm';
  loggedIn: Customer;
  loggC: boolean;
  logg: boolean;

  constructor(private bankerService: BankerService, private customerService: CustomerService, private router: Router, private actRt: ActivatedRoute) {
    this.loggedIn = null;
    sessionStorage.setItem('logged', JSON.stringify(this.loggedIn));
    this.logg = false;
  }

  ngOnInit() {
    this.load();
  }

  load() {
    if(this.customerService.loggedIn) {
      this.logg = true;
    } else if(this.bankerService.loggedIn) {
      this.logg=true;
    }

    console.log(this.logg);
  }

  logOut() {
    // if(this.bankerService.loggedIn) {
    //   this.bankerService.loggedIn = false;
    //   this.router.navigateByUrl("");
    // alert('You have been logged Out');
    // } else if(this.customerService.loggedIn) {
    //   this.customerService.loggedIn = false;
    //   sessionStorage.removeItem('logged');
    // this.router.navigateByUrl("");
    // alert('You have been logged Out');
    // } else {

    // }

    
  }
}
