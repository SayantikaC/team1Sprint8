import { Component, OnInit } from '@angular/core';
import { Customer } from '../model/customer.model';
import { CustomerService } from '../service/customer.service';
import { BankerService } from '../service/banker.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Message } from '../model/message.model';
import { Banker } from '../model/banker.model';
import { Login } from '../model/login.model';
import { Application } from '../model/application.model';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  customer: Customer;
  customers: Customer[];
  message: Message;
  banker: Banker;
  bankers: Banker[];
  temp: string;
  logIn: Login;
 
  msg: string;
  passwordMessage: string;

  constructor(private customerService: CustomerService, private bankerService: BankerService,  private actRt: ActivatedRoute, private router: Router) {
    this.customer = new Customer();
    this.logIn = new Login();
    this.banker = new Banker();
    this.logIn.role="";
    this.logIn.userId = "";
    this.logIn.password = "";
    this.customer.userId = "";
    this.customer.password = "";
    this.banker.userId = "";
    this.banker.password = "";
    this.temp= "";
        // this.errorMessage = "something went wrong";
    this.msg = "Username and Password is required";
    this.passwordMessage = "Password is required";
  }
  
  ngOnInit() {
    this.load();
  }

  load() {
    
    this.customerService.getAll().subscribe(
      (data) => { this.customers = data; }
    );
  }

  login() {
    
    console.log(this.logIn.role);
    
    if(this.logIn.role === "") {
      alert(`Choose your role as a customer or banker`);
    } else if(this.logIn.role === "customer") {
      this.customer.userId = this.logIn.userId;
      this.customer.password = this.logIn.password;
              if(this.customer.userId === this.temp ) {
                alert(`${this.msg}`);
            } else if (this.customer.password === this.temp) {
                alert(`${this.passwordMessage}`)
            }else {
              
              this.customerService.login(this.customer).subscribe(   
              (data) => {
                  this.message = data;
                  this.customer = this.message.customer;
                  
                  localStorage.setItem('c', JSON.stringify(this.customer));
                  sessionStorage.setItem('logged', JSON.stringify(this.customer));
                  if(this.customer.login===0) {
                    this.customerService.loggedIn = true;
                    console.log(this.customerService.loggedIn);
                    this.router.navigateByUrl("/updatePasswordPage");
                  }
                  else {
                    this.customerService.loggedIn = true;
                    console.log(this.customerService.loggedIn);
                    this.router.navigateByUrl("/customerHome"); 
                  }          
                },
                (error) => {
                  console.log(error);
                  this.customerService.errorMessage = error;
                  alert(`${this.customerService.errorMessage}`)
                }
              );
            }
    } else {
        this.banker.userId = this.logIn.userId;
        this.banker.password = this.logIn.password;
        console.log(this.banker.password);
        if(this.banker.userId === this.temp ) {
          alert(`${this.msg}`);
      } else if (this.banker.password === this.temp) {
          alert(`${this.passwordMessage}`)
      }else {
        console.log(this.banker.bankerId);
        console.log(this.banker.userId);
        this.bankerService.login(this.banker).subscribe(   
        (data) => {
            this.message = data;
            this.banker = this.message.banker;
            console.log(this.message.banker.bankerId);
            localStorage.setItem('b', JSON.stringify(this.banker));
            sessionStorage.setItem('logged', JSON.stringify(this.banker));
            this.bankerService.loggedIn = true;
            console.log(this.bankerService.loggedIn);
            this.router.navigateByUrl("/bankerViewPage"); 
          },
        (error) => {
            console.log(error);
            this.bankerService.errorMessage = error;
            alert(`${this.bankerService.errorMessage}`)
          }
        );
      }
    }
    
    }

}
