import { Component, OnInit } from '@angular/core';
import { Message } from '../model/message.model';
import { Application } from '../model/application.model';
import { Customer } from '../model/customer.model';
import { BankerService } from '../service/banker.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-display-status',
  templateUrl: './display-status.component.html',
  styleUrls: ['./display-status.component.css']
})
export class DisplayStatusComponent implements OnInit {

  // message:Message;
  application: Application;
  customer: Customer;
  approvedStatus: string;
  show: boolean;
  deniedShow: boolean;

  constructor(private router: Router, private actRt: ActivatedRoute) {
    this.customer = new Customer();
    this.application = new Application();
    this.approvedStatus = "APPROVED";
    this.show = false;
    this.deniedShow = false;
   }

  ngOnInit() {
    this.load();
  }

  load() {
    this.application = JSON.parse(localStorage.getItem('app'));
    if(this.application.applicationStatus === this.approvedStatus) {
      this.customer = JSON.parse(localStorage.getItem('cust'));
      this.show = true;
    } else if(this.application.applicationStatus === "DENIED") {
      this.deniedShow = true;
    }
    
    console.log(this.application.applicationStatus);
    
  }

  logout() {
    sessionStorage.remove('logged');
    this.router.navigateByUrl("");
  }

  
}
