import { Component, OnInit } from '@angular/core';
import { Application } from '../model/application.model';
import { Applicant } from '../model/applicant.model';
import { Address } from '../model/address.model';
import { CustomerService } from '../service/customer.service';
import { Message } from '../model/message.model';
import { Route, Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {
  submitted = false;
  application: Application;
  applicationNew: Application;
  applicant = new Applicant();
  address = new Address();
  datestr: string;
  timeDiff: number;
  age: number;
  num1: number;
  num2: number;
  minAge: number;
  chkAge:boolean;
  message:Message;

  constructor(private customerService: CustomerService, private router: Router, private actRt: ActivatedRoute) {
    this.submitted = false;
    this.address = new Address();
    this.applicant = new Applicant();
    this.application = new Application();
    this.message = new Message();
    this.applicationNew = new Application();
    this.chkAge=false;
   }
  ngOnInit() {
  }
  
  
  
  checkAge() {
    
    this.applicant.dob = new Date(this.datestr);
    this.minAge = 18;

    var timeDiff = Math.abs(Date.now() - new Date(this.applicant.dob).getTime());
    this.age = Math.floor(timeDiff / (1000 * 3600 * 24) / 365.25);
    
    
    
    
    // alert("my age is " + age);
    if (this.age < this.minAge) {
      alert("Age should be greater than 18");
      this.chkAge=true;
    }
      else{this.chkAge=false;
      }
  
}

  checkPhone() {
    var ppmn = parseFloat((<HTMLInputElement>document.getElementById("pmn")).value);
    var aamn = parseFloat((<HTMLInputElement>document.getElementById("amn")).value);

    if (ppmn == aamn) {
      alert("Alternate and primary mobile number can't be same");
     this.chkAge=true;
    }
    else{this.chkAge=false;
    }
    
   
      

    }

  

  addressFunction() 
{
   let element = <HTMLInputElement>document.getElementById("same");


if (element.checked) 
{ 
  (<HTMLInputElement>document.getElementById("ch")).value=(<HTMLInputElement>document.getElementById("ph")).value;
  (<HTMLInputElement>document.getElementById("cs")).value=(<HTMLInputElement>document.getElementById("ps")).value;
  (<HTMLInputElement>document.getElementById("ca")).value=(<HTMLInputElement>document.getElementById("pa")).value;
  (<HTMLInputElement>document.getElementById("cl")).value=(<HTMLInputElement>document.getElementById("pl")).value;
  (<HTMLInputElement>document.getElementById("cc")).value=(<HTMLInputElement>document.getElementById("pc")).value;
  (<HTMLInputElement>document.getElementById("cst")).value=(<HTMLInputElement>document.getElementById("pst")).value;
  (<HTMLInputElement>document.getElementById("cp")).value=(<HTMLInputElement>document.getElementById("pp")).value;




// 	document.getElementById('cs').value=document. 
// 			getElementById('ps').value;
// document.getElementById('ca').value=document. 
// 			getElementById('pa').value; 
// 	document.getElementById('cl').value=document. 
// 			getElementById('pl').value;
// document.getElementById('cc').value=document. 
// 			getElementById('pc').value; 
// 	document.getElementById('cst').value=document. 
// 			getElementById('pst').value;
// document.getElementById('cp').value=document. 
// 			getElementById('pp').value;
// 
} 
	
else
{ 
  (<HTMLInputElement>document.getElementById("ch")).value="";
  (<HTMLInputElement>document.getElementById("cs")).value="";
  (<HTMLInputElement>document.getElementById("ca")).value="";
  (<HTMLInputElement>document.getElementById("cl")).value="";
  (<HTMLInputElement>document.getElementById("cc")).value="";
  (<HTMLInputElement>document.getElementById("cst")).value="";
  (<HTMLInputElement>document.getElementById("cp")).value="";





// 	document.getElementById('ch').value=""; 
// 	document.getElementById('cs').value=""; 
// document.getElementById('ca').value=""; 
// document.getElementById('cl').value=""; 
// document.getElementById('cc').value="";
// document.getElementById('cst').value="";
// document.getElementById('cp').value="";  
} 
} 
signup(){
  // this.submitted = true;
  this.applicant.address= this.address;
  this.application.primaryApplicant = this.applicant;
      this.customerService.signup(this.application).subscribe(
          (data) => {
            this.message = data;
            this.applicationNew=this.message.application;
            alert(`Your application has been submitted`);
            localStorage.setItem('newAppl', JSON.stringify(this.applicationNew));
            this.router.navigateByUrl("applicationSubmitPage");
          }
      );
    }
  


  // signup() {
  //   this.applicant.dob = new Date(this.datestr);

  //   var timeDiff = Math.abs(Date.now() - new Date(this.applicant.dob).getTime());
  //   this.age = Math.floor(timeDiff / (1000 * 3600 * 24) / 365.25);
  //   alert("my age is " + this.age);
  //   if (this.age < 18) {
  //     alert('Age should be greater than 18');

  //   }
  //   this.num1 = parseFloat((<HTMLInputElement>document.getElementById("pmn")).value);
  //   this.num2 = parseFloat((<HTMLInputElement>document.getElementById("amn")).value);
  //   if (this.num1 == this.num2) {
  //     alert("Alternate and primary mobile number can't be same");

  //   }
  // }
}