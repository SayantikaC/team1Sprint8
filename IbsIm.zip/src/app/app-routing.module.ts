import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


import { ApplicationComponent } from './application/application.component';
import { HomeComponent } from './home/home.component';
import { CheckStatusComponent} from './check-status/check-status.component';
import { LoginComponent} from './login/login.component';
import { DisplayStatusComponent } from './display-status/display-status.component';
import { RandomPageComponent } from './random-page/random-page.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { JointSignUpComponent } from './joint-sign-up/joint-sign-up.component';
import { UpdatePasswordPageComponent } from './update-password-page/update-password-page.component';
import { BankerViewPageComponent } from './banker-view-page/banker-view-page.component';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { ApplicationCheckComponent } from './application-check/application-check.component';
import { ApplicationSubmitPageComponent} from './application-submit-page/application-submit-page.component';
import { RemarksComponent } from './remarks/remarks.component';

const routes: Routes = [
  
  {path:'application', component:ApplicationComponent },
  {path: 'customerHome', component:HomeComponent},
  {path: 'checkStatus', component:CheckStatusComponent},
  {path: 'login', component:LoginComponent},
  {path: 'displayStatus', component:DisplayStatusComponent},
  {path: '', component:LoginComponent},
  {path: 'underMaintenance', component:RandomPageComponent},
  {path: 'signUp', component:SignUpComponent},
  {path: 'jointSignUp', component:JointSignUpComponent},
  {path: 'updatePasswordPage', component:UpdatePasswordPageComponent},
  {path: 'bankerViewPage', component:BankerViewPageComponent},
  {path: 'userProfile', component:UserProfileComponent},
  {path: 'applicationCheck', component:ApplicationCheckComponent},
  {path: 'applicationSubmitPage', component:ApplicationSubmitPageComponent},
  {path: 'remarks', component:RemarksComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})

export class AppRoutingModule { }

export const routingComponents = [HomeComponent, ApplicationComponent, DisplayStatusComponent, BankerViewPageComponent, UserProfileComponent, ApplicationCheckComponent, ApplicationSubmitPageComponent, RemarksComponent]