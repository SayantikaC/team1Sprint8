import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-random-page',
  templateUrl: './random-page.component.html',
  styleUrls: ['./random-page.component.css']
})
export class RandomPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
