import { Component, OnInit } from '@angular/core';
import { Customer } from '../model/customer.model';
import { Password } from '../model/password.model';
import { CustomerService } from '../service/customer.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-update-password-page',
  templateUrl: './update-password-page.component.html',
  styleUrls: ['./update-password-page.component.css']
})
export class UpdatePasswordPageComponent implements OnInit {

 customer: Customer;
 password: Password;

  constructor(private customerService: CustomerService, private actRt: ActivatedRoute, private router: Router) { 
    this.customer = new Customer();
    this.password = new Password();
  }

  ngOnInit() {
    this.load();
  }

  load() {
    this.customer = JSON.parse(localStorage.getItem('c'));
    
  }

  updatePassword() {
    console.log(this.password.newPassword);
    console.log(this.password.confirmPassword);
    console.log(this.customer.userId);
    this.password.userId = this.customer.userId;
    console.log(this.password.userId);
    
    if(this.password.newPassword===this.password.confirmPassword) {
        this.customerService.updatePassword(this.password).subscribe(
            (data) => {
                
              this.router.navigateByUrl("/customerHome");
            }
        );
    } else {
      alert(`Both the passwords should be same`);
        console.log("wtf are you doing?");
    }
  }

}
