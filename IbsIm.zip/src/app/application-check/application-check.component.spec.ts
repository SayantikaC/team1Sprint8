import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApplicationCheckComponent } from './application-check.component';

describe('ApplicationCheckComponent', () => {
  let component: ApplicationCheckComponent;
  let fixture: ComponentFixture<ApplicationCheckComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApplicationCheckComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApplicationCheckComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
