import { Component, OnInit } from '@angular/core';
import { Application } from '../model/application.model';
import { Router, ActivatedRoute } from '@angular/router';
import { BankerService } from '../service/banker.service';
import { Message } from '../model/message.model';
import { Customer } from '../model/customer.model';

@Component({
  selector: 'app-application-check',
  templateUrl: './application-check.component.html',
  styleUrls: ['./application-check.component.css']
})
export class ApplicationCheckComponent implements OnInit {

  application: Application;
  message: Message;
  customer: Customer;
  isJoint: boolean;

  constructor(private bankerService: BankerService, private router: Router, private actRt: ActivatedRoute) {
    this.application = new Application();
    this.message = new Message();
    this.customer = new Customer();
    this.isJoint = false;
   }

  ngOnInit() {
    this.load();
  }

  load() {
    
    this.application = JSON.parse(localStorage.getItem('bankAppl'));
    console.log(this.application.accountType);
    if(this.application.accountType == "JOINT_SAVINGS") {
      this.isJoint = true;
      console.log(this.isJoint);
    }
  }

  leave() {
    this.router.navigateByUrl("/bankerViewPage");
  }

  deny() {
    localStorage.setItem('forRemarks',JSON.stringify(this.application))
    this.router.navigateByUrl("/remarks");
  }

  approve() {
    if (confirm("Are you sure you want to approve the customer?")) {

      this.bankerService.approveApplication(this.application).subscribe(
        (data) => {
          this.message = data;
          this.customer = this.message.customer;
          alert(`The application has been approved for: ` + this.application.applicationId + "\nCustomer ID generated: "+ this.customer.uci);

          this.router.navigateByUrl("/bankerViewPage");

        }
      );
    }    
  }

  logout() {
    sessionStorage.remove('logged');
    this.router.navigateByUrl("");
  }

}
