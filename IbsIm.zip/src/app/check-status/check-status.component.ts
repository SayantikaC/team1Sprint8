import { Component, OnInit } from '@angular/core';
import { Application} from '../model/application.model';
import { CustomerService } from '../service/customer.service';
import { Message } from '../model/message.model';
import { ActivatedRoute, Router } from '@angular/router';
import { Customer } from '../model/customer.model';

@Component({
  selector: 'app-check-status',
  templateUrl: './check-status.component.html',
  styleUrls: ['./check-status.component.css']
})
export class CheckStatusComponent implements OnInit {

  
  application: Application;
  
  applications: Application[];
  message: Message;
  customer: Customer;
  applicationId: number;
  appId: number;
  approvedStatus: string;
  emptyInput: number;
  bool: boolean;
  // let approvedStatus: ApplicationStatus= ApplicationStatus.APPROVED;
  // let deniedStatus: ApplicationStatus= ApplicationStatus.DENIED;
  



  constructor(private customerService: CustomerService, private actRt: ActivatedRoute, private router: Router) {
    this.application = new Application();
    this.bool = false;
    this.customer= new Customer();
    this.emptyInput = -1;
    this.approvedStatus = "APPROVED";
    this.applicationId = -1;
    this.appId = -1;
  
  }

  ngOnInit() {
    this.load();
  }

  load() {
    
  }

  checkStatus() {

    if((<HTMLInputElement>document.getElementById("applicationId")).value=="") {
      alert(`Input field can't be emptuy`);
    } else {
      this.customerService.checkStatus(this.application.applicationId).subscribe(
        (data) => {
          this.message = data;
          this.application = this.message.application;
          console.log(this.application.applicationStatus);
          localStorage.setItem('app', JSON.stringify(this.application));
          console.log("hello"+this.application.applicationStatus);
          if(this.application.applicationStatus === this.approvedStatus) {
            console.log(this.message.customer.firstName);
            localStorage.setItem('cust', JSON.stringify(this.message.customer));
          }       
          this.router.navigateByUrl("/displayStatus"); 
        },
        (error) => {
          console.log(error);
          this.customerService.errorMessage = error;
          alert(`${this.customerService.errorMessage}`)
        }
      );
    }
    }
    
    
      
    

}


enum ApplicationStatus {
  PENDING, APPROVED, DENIED
}