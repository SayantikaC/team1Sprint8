import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpClientModule } from '@angular/common/http';

import { AppRoutingModule, routingComponents } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent} from './home/home.component';
import { CustomerComponent } from './customer/customer.component';
import { ApplicationComponent } from './application/application.component';
import { CheckStatusComponent } from './check-status/check-status.component';
import { LoginComponent } from './login/login.component';
import { DisplayStatusComponent } from './display-status/display-status.component';
import { RandomPageComponent } from './random-page/random-page.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { JointSignUpComponent } from './joint-sign-up/joint-sign-up.component';
import { UpdatePasswordPageComponent } from './update-password-page/update-password-page.component';
import { BankerViewPageComponent } from './banker-view-page/banker-view-page.component';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { ApplicationCheckComponent } from './application-check/application-check.component';
import { RemarksComponent } from './remarks/remarks.component';
import { ApplicationSubmitPageComponent } from './application-submit-page/application-submit-page.component';


@NgModule({
  declarations: [
    AppComponent,
    CustomerComponent,
    ApplicationComponent,
    routingComponents,
    CheckStatusComponent,
    LoginComponent,
    HomeComponent,
    DisplayStatusComponent,
    RandomPageComponent,
    SignUpComponent,
    JointSignUpComponent,
    UpdatePasswordPageComponent,
    BankerViewPageComponent,
    UserProfileComponent,
    ApplicationCheckComponent,
    RemarksComponent,
    ApplicationSubmitPageComponent,

  ], 
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [
    HttpClient
  ],
  bootstrap: [AppComponent]
})
export class AppModule { 
}
