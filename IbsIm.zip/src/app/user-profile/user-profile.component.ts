import { Component, OnInit } from '@angular/core';
import { Application } from '../model/application.model';
import { Customer } from '../model/customer.model'
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css']
})
export class UserProfileComponent implements OnInit {

  application: Application;
  customer:Customer;
  datestr: string;

  constructor(private router: Router, private actRt: ActivatedRoute) {
    this.application = new Application();
    this.customer = new Customer();
    this.customer.dob = new Date(this.datestr);


   }

  ngOnInit() {
    this.load();
  }

  load() {
   this.application = JSON.parse(localStorage.getItem('app'));
   this.customer = JSON.parse(localStorage.getItem('c'));
   console.log(this.customer.lastName);
  }

  logout() {
    sessionStorage.remove('logged');
    this.router.navigateByUrl("");
  }

}
