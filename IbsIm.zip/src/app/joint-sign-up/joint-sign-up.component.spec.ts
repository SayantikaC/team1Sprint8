import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { JointSignUpComponent } from './joint-sign-up.component';

describe('JointSignUpComponent', () => {
  let component: JointSignUpComponent;
  let fixture: ComponentFixture<JointSignUpComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ JointSignUpComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JointSignUpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
