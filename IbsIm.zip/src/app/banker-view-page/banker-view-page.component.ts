import { Component, OnInit } from '@angular/core';
import { Banker } from '../model/banker.model';
import { BankerService } from '../service/banker.service';
import { Application } from '../model/application.model';
import { Message } from '../model/message.model';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-banker-view-page',
  templateUrl: './banker-view-page.component.html',
  styleUrls: ['./banker-view-page.component.css']
})
export class BankerViewPageComponent implements OnInit {
  message:Message;
  banker:Banker;
  application:Application;
  approvedStatus: string;
  applications: Application[];
  approvedApplications: Application[];
  deniedApplications: Application[];
  pendingApplications: Application[];
  bankerAssignedApplications: Application[];
  i: number;

  constructor(private bankerService: BankerService, private actRt: ActivatedRoute, private router: Router) { 
    this.banker = new Banker();
    this.message= new Message();
    this.application= new Application();
    this.applications = [];
    this.approvedApplications = [];
    this.bankerAssignedApplications = [];
    this.approvedStatus = "APPROVED";
  }

  ngOnInit() {
    this.load();
  }

  load(){
    this.banker = JSON.parse(localStorage.getItem('b'));
    this.getAllApplications();
    this.getAllApprovedApplications();
    this.getAllPendingApplications();
    this.getAllDeniedApplications();
    this.getAllPendingForBanker();
    this.approvedStatus = "APPROVED";
  }

  getAllApplications() {
    this.bankerService.getAllApplications().subscribe(
      (data) => {
        this.message = data;
        this.applications = this.message.applications;


        for(var i in this.applications) {
          console.log(i);
        }
        // localStorage.setItem('applications', JSON.stringify(this.applications));

      }
    );
  }

  getAllApprovedApplications() {
    this.bankerService.getAllApprovedApplications().subscribe(
      (data) => {
        this.message = data;
        this.approvedApplications = this.message.applications;
      });
  }

  getAllPendingApplications() {
    this.bankerService.getAllPendingApplications().subscribe(
      (data) => {
        this.message = data;
        this.pendingApplications = this.message.applications;
      });
  }

  getAllDeniedApplications() {
    this.bankerService.getAllDeniedApplications().subscribe(
      (data) => {
        this.message = data;
        this.deniedApplications = this.message.applications;
      }
    );
  }

  getAllPendingForBanker() {
    this.bankerService.getAllPendingForBankerApplications(this.banker.bankerId).subscribe(
      (data) => {
        this.message = data;
        this.bankerAssignedApplications = this.message.applications;
      }
    );
  }

  viewApplication(appId: number) {

    this.bankerService.viewApplication(appId).subscribe(
      (data) => {
        this.message = data;
        this.application = this.message.application;
        localStorage.setItem('appl', JSON.stringify(this.application));
        this.router.navigateByUrl("/application")

      }
    );
  }

  viewApplicationForBanker(appId: number) {

    this.bankerService.viewApplication(appId).subscribe(
      (data) => {
        this.message = data;
        this.application = this.message.application;
        localStorage.setItem('bankAppl', JSON.stringify(this.application));
        this.router.navigateByUrl("/applicationCheck")

      }
    );
  }

  logout() {
    sessionStorage.remove('logged');
    this.router.navigateByUrl("");
  }

}
