import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BankerViewPageComponent } from './banker-view-page.component';

describe('BankerViewPageComponent', () => {
  let component: BankerViewPageComponent;
  let fixture: ComponentFixture<BankerViewPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BankerViewPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BankerViewPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
