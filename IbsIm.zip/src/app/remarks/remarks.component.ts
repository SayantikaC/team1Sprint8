import { Component, OnInit } from '@angular/core';
import { Application } from '../model/application.model';
import { BankerService } from '../service/banker.service';
import { Message } from '../model/message.model';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-remarks',
  templateUrl: './remarks.component.html',
  styleUrls: ['./remarks.component.css']
})
export class RemarksComponent implements OnInit {

  application: Application;
  message: Message;

  constructor(private bankerService: BankerService, private router: Router, private actRt: ActivatedRoute) {
    this.application = new Application();
    this.message = new Message();
   }

  ngOnInit() {
    this.load();
  }

  load() {
    this.application = JSON.parse(localStorage.getItem('forRemarks'));
    
  }

  denyApplication() {
    alert(this.application.applicationId);
    console.log(this.application.remarks);
    this.bankerService.denyApplication(this.application).subscribe(
      (data) => {
          this.message = data;
          this.application = this.message.application;
          console.log("newwwww "+ this.application.remarks);
          alert('Application denied for ' + this.application.applicationId);
          this.router.navigateByUrl('/bankerViewPage')
      }
    );

  }

  logout() {
    sessionStorage.remove('logged');
    this.router.navigateByUrl("");
  }

}
